﻿Imports System.ComponentModel
Imports System.Data.SQLite
Imports System.IO
Imports System.Web.UI.WebControls
Imports Guna.UI2.WinForms.Enums

Public Class Form5
    Private dbCommand As String = ""
    Private bindingSrc As BindingSource
    Private diretorio As String
    Private dbName As String = "banco.db"
    Private dbPath As String = Application.StartupPath & "\banco\" & dbName
    Private conString As String = "Data Source=" & dbPath & ";Version=3"
    Private connection As New SQLiteConnection(conString)

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txt_nome.Focus()
        connection.Open()
        cmb_parametro.Items.Add("CPF")
        cmb_parametro.Items.Add("Nome")
    End Sub

    Sub limpar_cadastro()
        txt_cpf.Text = ""
        txt_email.Text = ""
        txt_nome.Text = ""
        txt_telefone.Text = ""
        txt_valor.Text = ""
        cmb_data.Text = ""
        pb_foto.Image = Nothing
    End Sub


    Private Sub btn_editar_Click(sender As Object, e As EventArgs) Handles btn_editar.Click
        Dim sql As String = "SELECT * FROM tb_clientes WHERE cpf='" & txt_cpf.Text & "' AND n_func = '" & funcionario_logado & "';"  'adicionar um filtro para cada funcionário, não ver o cliente do outro.
        Dim command As New SQLiteCommand(sql, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                Dim update_cpf As String = reader("cpf").ToString()
                Dim update_nome As String = reader("nome").ToString()
                Dim update_email As String = reader("email").ToString()
                Dim update_data As String = reader("data_nasc").ToString()
                Dim update_telefone As String = reader("telefone").ToString()
                Dim update_foto As String = reader("foto").ToString()

                sql = "UPDATE tb_clientes SET cpf = '" & txt_cpf.Text & "', nome= '" & txt_nome.Text & "', email='" & txt_email.Text & "', data_nasc='" & cmb_data.Text & "',telefone='" & txt_telefone.Text & "',foto='" & diretorio & "' WHERE cpf='" & update_cpf & "' AND n_func = '" & funcionario_logado & "'"
                Dim command2 As New SQLiteCommand(sql, connection)
                Try
                    command2.ExecuteNonQuery()
                    MsgBox("EDIÇÃO FEITA COM SUCESSO!")
                    limpar_cadastro()
                Catch ex As Exception
                    MsgBox("Foi impossível realizar a edição do usuário!")
                End Try
            Else
                MsgBox("Não há cadastro existente com esse nome de usuário!", MsgBoxStyle.Exclamation + vbOKOnly)
            End If
        End Using
    End Sub


    Private Sub btn_deletar_Click(sender As Object, e As EventArgs) Handles btn_deletar.Click
        Dim sql As String = "SELECT * FROM tb_clientes WHERE cpf='" & txt_cpf.Text & "';"
        Dim command As New SQLiteCommand(sql, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                sql = "DELETE FROM tb_clientes WHERE cpf= '" & txt_cpf.Text & "'"
                Dim command2 As New SQLiteCommand(sql, connection)
                Try
                    resp = MsgBox("Deseja realmente realizar a deleção?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
                    If resp = vbYes Then
                        command2.ExecuteNonQuery()
                        MsgBox("Deleção efetuada com sucesso!")
                        limpar_cadastro()
                    Else
                        Exit Sub
                    End If
                Catch ex As Exception
                    MsgBox("Não foi possível realizar a deleção!")
                End Try
            End If
        End Using
    End Sub

    Private Sub btn_deslogar_Click(sender As Object, e As EventArgs) Handles btn_deslogar.Click
        Form3.Show()
        Me.Close()

    End Sub


    Private Sub btn_filtrar_Click(sender As Object, e As EventArgs) Handles btn_filtrar.Click
        Dim sql As String
        If cmb_parametro.SelectedItem = "Nome" Then
            sql = "select * from tb_clientes where nome like '" & txt_valor.Text & "%' AND n_func = '" & funcionario_logado & "'"
            Dim command As New SQLiteCommand(sql, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                Try
                    cont = 1
                    dgv_dados.Rows.Clear()
                    While reader.Read()
                        dgv_dados.Rows.Add(cont, reader("cpf"), reader("nome"), reader("email"), reader("telefone"))
                        cont = cont + 1
                    End While
                    Select Case cont
                        Case 1
                            MsgBox("Você está tentando acessar um cliente em que não tem acesso!")
                        Case Else
                            tab_control.SelectedIndex = 1
                    End Select
                Catch ex As Exception
                    MsgBox("Não há um registro com esse Nome! Ou foi inserido um parametro errado!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
                End Try
            End Using
        ElseIf cmb_parametro.SelectedItem = "CPF" Then
            sql = "select * from tb_clientes where cpf like '" & txt_valor.Text & "%' AND n_func = '" & funcionario_logado & "'"
            Dim command As New SQLiteCommand(sql, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                Try
                    cont = 1
                    dgv_dados.Rows.Clear()
                    While reader.Read()
                        dgv_dados.Rows.Add(cont, reader("cpf"), reader("nome"), reader("email"), reader("telefone"))
                        cont = cont + 1
                    End While
                    Select Case cont
                        Case 1
                            MsgBox("Você está tentando acessar um cliente em que não tem acesso!")
                        Case Else
                            tab_control.SelectedIndex = 1
                    End Select
                Catch ex As Exception
                    MsgBox("Não há um registro com esse CPF! Ou foi inserido um parametro errado", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
                End Try
            End Using
        Else
            MsgBox("Escolha um parâmetro, antes de filtrar!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
        End If
    End Sub



    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Dim sql As String
        With dgv_dados
            If .CurrentRow.Cells(5).Selected Then
                Dim aux_cpf As String = .CurrentRow.Cells(1).Value
                sql = "SELECT * FROM tb_clientes WHERE cpf='" & aux_cpf & "' AND n_func = '" & funcionario_logado & "';"
                Dim command As New SQLiteCommand(sql, connection)
                Using reader As SQLiteDataReader = command.ExecuteReader()
                    Try
                        If reader.Read() Then
                            tab_control.SelectedIndex = 0
                            txt_cpf.Text = reader("cpf").ToString()
                            cmb_data.Text = reader("data_nasc").ToString()
                            txt_nome.Text = reader("nome").ToString()
                            txt_email.Text = reader("email").ToString()
                            txt_telefone.Text = reader("telefone").ToString()
                            pb_foto.Load(Application.StartupPath & "\fotos\fotos_clientes" & "\" & reader("foto").ToString())
                            tab_control.SelectedIndex = 0
                            dgv_dados.ClearSelection()
                        End If
                    Catch ex As Exception
                        MsgBox("Não foi possível passar as informações para o campo!")
                    End Try
                End Using
            End If
        End With
    End Sub

    Private Sub btn_criar_Click(sender As Object, e As EventArgs) Handles btn_criar.Click
        Dim sql As String = "SELECT * FROM tb_clientes WHERE cpf='" & txt_cpf.Text & "';"

        Dim command As New SQLiteCommand(sql, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                If reader("cpf") = txt_cpf.Text Then
                    MsgBox("Há um registro com esse CPF:  insira outro cpf!", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical)
                    txt_cpf.Clear()
                End If
            Else
                sql = "INSERT INTO tb_clientes VALUES ('" & txt_cpf.Text & "','" & txt_nome.Text & "','" & txt_email.Text & "','" & cmb_data.Text & "','" & txt_telefone.Text & "','" & diretorio & "','" & funcionario_logado & "');"
                Dim command2 As New SQLiteCommand(sql, connection)
                Try
                    command2.ExecuteNonQuery()
                    MsgBox("CRIAÇÃO EFETUADA COM SUCESSO!", MsgBoxStyle.Information + vbOKOnly)
                    limpar_cadastro()
                Catch ex As Exception
                    MsgBox("Foi impossível realizar a criação, aqui há algumas possíveis razões!" + vbNewLine &
                       "1. Você tentou criar uma conta com usuário ou CPF já registrados no sistema;" + vbNewLine &
                       "2. Você já fez o cadastro dessa conta;" + vbNewLine &
                      "3. Você não completou todos os campos apropriadamente;" + vbNewLine &
                     "4. Você deixou pelo menos um campo vazio; ", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
                End Try
            End If
        End Using
    End Sub

    Private Sub pb_foto_Click(sender As Object, e As EventArgs) Handles pb_foto.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\fotos\fotos_clientes"
                .ShowDialog()
                diretorio = .FileName
                pb_foto.Load(diretorio)
                diretorio = Path.GetFileName(diretorio)
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub
End Class