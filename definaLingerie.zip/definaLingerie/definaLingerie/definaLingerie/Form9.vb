﻿Imports System.Data.SQLite
Imports System.Security.Principal

Public Class Form9
    Private dbCommand As String = ""
    Private bindingSrc As BindingSource
    Private dbName As String = "banco.db"
    Private dbPath As String = Application.StartupPath & "\banco\" & dbName
    Private conString As String = "Data Source=" & dbPath & ";Version=3"
    Private connection As New SQLiteConnection(conString)
    Private Sub btn_criar_Click(sender As Object, e As EventArgs) Handles btn_criar.Click
        Dim SQL As String

        If txt_cliente.Text = Nothing And txt_qtde.Text = Nothing Then
            SQL = "SELECT * from tb_clientes;"
            Dim command As New SQLiteCommand(SQL, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                cont = 1
                dgv_dados.Rows.Clear()
                While reader.Read()
                    dgv_dados.Rows.Add(cont, reader("nome"), reader("n_func"), reader("telefone"), reader("data_nasc"))
                    cont = cont + 1
                End While
                tab_control.SelectedIndex = 1
            End Using
        ElseIf Not txt_cliente.Text = Nothing And txt_qtde.Text = Nothing Then
            SQL = "SELECT * from tb_clientes WHERE nome like '" & txt_cliente.Text & "%';"
            Dim command As New SQLiteCommand(SQL, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                cont = 1
                dgv_dados.Rows.Clear()
                While reader.Read()
                    dgv_dados.Rows.Add(cont, reader("nome"), reader("n_func"), reader("telefone"), reader("data_nasc"))
                    cont = cont + 1
                End While
                tab_control.SelectedIndex = 1
            End Using
        ElseIf txt_cliente.Text = Nothing And Not txt_qtde.Text = Nothing Then
            SQL = "SELECT * from tb_clientes;"
            Dim command As New SQLiteCommand(SQL, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                cont = 1
                dgv_dados.Rows.Clear()
                While reader.Read() And cont <= CInt(txt_qtde.Text)
                    dgv_dados.Rows.Add(cont, reader("nome"), reader("n_func"), reader("telefone"), reader("data_nasc"))
                    cont = cont + 1
                End While
                tab_control.SelectedIndex = 1
            End Using
        Else
            SQL = "SELECT * from tb_clientes WHERE nome like '" & txt_cliente.Text & "%';"
            Dim command As New SQLiteCommand(SQL, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                cont = 1
                dgv_dados.Rows.Clear()
                While reader.Read() And cont <= CInt(txt_qtde.Text)
                    dgv_dados.Rows.Add(cont, reader("nome"), reader("n_func"), reader("telefone"), reader("data_nasc"))
                    cont = cont + 1
                End While
                tab_control.SelectedIndex = 1
            End Using
        End If
    End Sub

    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles Me.Load
        connection.Open()
    End Sub

    Private Sub btn_deslogar_Click(sender As Object, e As EventArgs) Handles btn_deslogar.Click
        Form7.Show()
        Me.Close()
    End Sub
End Class
