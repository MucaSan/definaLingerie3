﻿Imports System.Data.SQLite

Public Class Form8
    Private dbCommand As String = ""
    Private bindingSrc As BindingSource
    Private dbName As String = "banco.db"
    Private dbPath As String = Application.StartupPath & "\banco\" & dbName
    Private conString As String = "Data Source=" & dbPath & ";Version=3"
    Private connection As New SQLiteConnection(conString)
    Private Sub btn_criar_Click(sender As Object, e As EventArgs) Handles btn_criar.Click
        Dim SQL As String
        Dim data1 As String
        Dim data2 As String
        Dim format As String
        Dim periodo_inicial As DateTime
        Dim periodo_final As DateTime
        data1 = cmb_inicial.Text
        data2 = cmb_final.Text
        format = "dd/MM/yyyy"
        periodo_inicial = DateTime.ParseExact(data1, format, Nothing)
        periodo_final = DateTime.ParseExact(data2, format, Nothing)
        data1 = periodo_inicial.ToString("yyyyMMdd")
        data2 = periodo_final.ToString("yyyyMMdd")
        If periodo_inicial >= periodo_final Then
            MsgBox("Insira um valor válido! A data inicial deve ser menor do que a data final!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
        Else
            SQL = "SELECT *
FROM tb_produtos where substr(data_criacao,7,4)||substr(data_criacao, 4,2) || substr(data_criacao,1,2) BETWEEN '" & data1 & "' AND 
'" & data2 & "';"
            Dim command As New SQLiteCommand(SQL, connection)
            command.CommandText = SQL
            Using reader As SQLiteDataReader = command.ExecuteReader()
                cont = 1
                soma = 0
                dgv_dados.Rows.Clear()
                While reader.Read()
                    dgv_dados.Rows.Add(cont, reader("n_func"), reader("qtde"), reader("preco"))
                    cont = cont + 1
                    soma = soma + CInt(reader("preco"))
                End While
                tab_control.SelectedIndex = 1
                lbl_inicial.Text = cmb_inicial.Text
                lbl_final.Text = cmb_final.Text
                lbl_total.Text = soma.ToString()
            End Using
        End If
    End Sub

    Private Sub Form8_Load(sender As Object, e As EventArgs) Handles Me.Load
        connection.Open()
    End Sub

    Private Sub btn_deslogar_Click(sender As Object, e As EventArgs) Handles btn_deslogar.Click
        Form7.Show()
        Me.Close()
    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub
End Class