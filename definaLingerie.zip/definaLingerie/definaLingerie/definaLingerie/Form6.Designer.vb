﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        Me.cmb_renda = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.cmb_cor = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.cmb_tamanho = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.cmb_tipo = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.btn_criar = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.txt_cliente = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt_preco = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txt_qtde = New Guna.UI2.WinForms.Guna2TextBox()
        Me.tab_control = New Guna.UI2.WinForms.Guna2TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.lbl_id = New System.Windows.Forms.Label()
        Me.btn_deletar = New Guna.UI2.WinForms.Guna2Button()
        Me.btn_editar = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.dgv_dados = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.Nº = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Identificador = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Nome = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Quantidade = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Preco = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Data = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Consultar = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Guna2ShadowForm1 = New Guna.UI2.WinForms.Guna2ShadowForm(Me.components)
        Me.Guna2DragControl1 = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2ControlBox1 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2ControlBox2 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2AnimateWindow1 = New Guna.UI2.WinForms.Guna2AnimateWindow(Me.components)
        Me.ts_filtro = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.txt_valor = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.cmb_parametro = New System.Windows.Forms.ToolStripComboBox()
        Me.btn_filtrar = New System.Windows.Forms.ToolStripButton()
        Me.btn_deslogar = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.tab_control.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgv_dados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2Panel1.SuspendLayout()
        Me.ts_filtro.SuspendLayout()
        CType(Me.btn_deslogar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmb_renda
        '
        Me.cmb_renda.BackColor = System.Drawing.Color.Transparent
        Me.cmb_renda.BorderRadius = 10
        Me.cmb_renda.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_renda.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_renda.FillColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.cmb_renda.FocusedColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmb_renda.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmb_renda.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmb_renda.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.cmb_renda.ItemHeight = 30
        Me.cmb_renda.Location = New System.Drawing.Point(372, 117)
        Me.cmb_renda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmb_renda.Name = "cmb_renda"
        Me.cmb_renda.Size = New System.Drawing.Size(319, 36)
        Me.cmb_renda.TabIndex = 7
        '
        'cmb_cor
        '
        Me.cmb_cor.BackColor = System.Drawing.Color.Transparent
        Me.cmb_cor.BorderRadius = 10
        Me.cmb_cor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_cor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_cor.FillColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.cmb_cor.FocusedColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmb_cor.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmb_cor.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmb_cor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.cmb_cor.ItemHeight = 30
        Me.cmb_cor.Location = New System.Drawing.Point(372, 38)
        Me.cmb_cor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmb_cor.Name = "cmb_cor"
        Me.cmb_cor.Size = New System.Drawing.Size(317, 36)
        Me.cmb_cor.TabIndex = 5
        '
        'cmb_tamanho
        '
        Me.cmb_tamanho.BackColor = System.Drawing.Color.Transparent
        Me.cmb_tamanho.BorderRadius = 10
        Me.cmb_tamanho.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_tamanho.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_tamanho.FillColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.cmb_tamanho.FocusedColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmb_tamanho.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmb_tamanho.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmb_tamanho.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.cmb_tamanho.ItemHeight = 30
        Me.cmb_tamanho.Location = New System.Drawing.Point(24, 199)
        Me.cmb_tamanho.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmb_tamanho.Name = "cmb_tamanho"
        Me.cmb_tamanho.Size = New System.Drawing.Size(220, 36)
        Me.cmb_tamanho.TabIndex = 3
        '
        'cmb_tipo
        '
        Me.cmb_tipo.BackColor = System.Drawing.Color.Transparent
        Me.cmb_tipo.BorderRadius = 10
        Me.cmb_tipo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmb_tipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_tipo.FillColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.cmb_tipo.FocusedColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmb_tipo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmb_tipo.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmb_tipo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.cmb_tipo.ItemHeight = 30
        Me.cmb_tipo.Location = New System.Drawing.Point(25, 117)
        Me.cmb_tipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmb_tipo.Name = "cmb_tipo"
        Me.cmb_tipo.Size = New System.Drawing.Size(219, 36)
        Me.cmb_tipo.TabIndex = 1
        '
        'btn_criar
        '
        Me.btn_criar.Animated = True
        Me.btn_criar.AutoRoundedCorners = True
        Me.btn_criar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.btn_criar.BorderRadius = 33
        Me.btn_criar.BorderThickness = 1
        Me.btn_criar.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btn_criar.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btn_criar.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btn_criar.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btn_criar.FillColor = System.Drawing.Color.White
        Me.btn_criar.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn_criar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.btn_criar.Location = New System.Drawing.Point(25, 298)
        Me.btn_criar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn_criar.Name = "btn_criar"
        Me.btn_criar.Size = New System.Drawing.Size(152, 68)
        Me.btn_criar.TabIndex = 6
        Me.btn_criar.Text = "Criar"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.DimGray
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(372, 90)
        Me.Guna2HtmlLabel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(45, 22)
        Me.Guna2HtmlLabel1.TabIndex = 7
        Me.Guna2HtmlLabel1.Text = "Renda"
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.DimGray
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(27, 172)
        Me.Guna2HtmlLabel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(65, 22)
        Me.Guna2HtmlLabel2.TabIndex = 8
        Me.Guna2HtmlLabel2.Text = "Tamanho"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.DimGray
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(24, 91)
        Me.Guna2HtmlLabel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(113, 22)
        Me.Guna2HtmlLabel3.TabIndex = 9
        Me.Guna2HtmlLabel3.Text = "Tipo do produto"
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.DimGray
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(372, 11)
        Me.Guna2HtmlLabel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(26, 22)
        Me.Guna2HtmlLabel4.TabIndex = 10
        Me.Guna2HtmlLabel4.Text = "Cor"
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.DimGray
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(25, 11)
        Me.Guna2HtmlLabel5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(116, 22)
        Me.Guna2HtmlLabel5.TabIndex = 11
        Me.Guna2HtmlLabel5.Text = "Nome do Cliente"
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.DimGray
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(255, 172)
        Me.Guna2HtmlLabel6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(40, 22)
        Me.Guna2HtmlLabel6.TabIndex = 12
        Me.Guna2HtmlLabel6.Text = "Preço"
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel7.ForeColor = System.Drawing.Color.DimGray
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(255, 90)
        Me.Guna2HtmlLabel7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(81, 22)
        Me.Guna2HtmlLabel7.TabIndex = 13
        Me.Guna2HtmlLabel7.Text = "Quantidade"
        '
        'txt_cliente
        '
        Me.txt_cliente.Animated = True
        Me.txt_cliente.BorderRadius = 10
        Me.txt_cliente.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_cliente.DefaultText = ""
        Me.txt_cliente.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_cliente.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_cliente.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_cliente.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_cliente.FillColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.txt_cliente.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_cliente.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_cliente.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.txt_cliente.Location = New System.Drawing.Point(24, 38)
        Me.txt_cliente.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_cliente.Name = "txt_cliente"
        Me.txt_cliente.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_cliente.PlaceholderText = ""
        Me.txt_cliente.SelectedText = ""
        Me.txt_cliente.Size = New System.Drawing.Size(319, 44)
        Me.txt_cliente.TabIndex = 0
        '
        'txt_preco
        '
        Me.txt_preco.Animated = True
        Me.txt_preco.BorderRadius = 10
        Me.txt_preco.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_preco.DefaultText = ""
        Me.txt_preco.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_preco.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_preco.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_preco.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_preco.FillColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.txt_preco.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_preco.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_preco.ForeColor = System.Drawing.Color.Black
        Me.txt_preco.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.txt_preco.Location = New System.Drawing.Point(255, 199)
        Me.txt_preco.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_preco.Name = "txt_preco"
        Me.txt_preco.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_preco.PlaceholderText = ""
        Me.txt_preco.SelectedText = ""
        Me.txt_preco.Size = New System.Drawing.Size(87, 44)
        Me.txt_preco.TabIndex = 4
        '
        'txt_qtde
        '
        Me.txt_qtde.Animated = True
        Me.txt_qtde.BorderRadius = 10
        Me.txt_qtde.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_qtde.DefaultText = ""
        Me.txt_qtde.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_qtde.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_qtde.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_qtde.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_qtde.FillColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.txt_qtde.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_qtde.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_qtde.ForeColor = System.Drawing.Color.Black
        Me.txt_qtde.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.txt_qtde.Location = New System.Drawing.Point(255, 117)
        Me.txt_qtde.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_qtde.Name = "txt_qtde"
        Me.txt_qtde.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_qtde.PlaceholderText = ""
        Me.txt_qtde.SelectedText = ""
        Me.txt_qtde.Size = New System.Drawing.Size(87, 44)
        Me.txt_qtde.TabIndex = 2
        '
        'tab_control
        '
        Me.tab_control.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.tab_control.Controls.Add(Me.TabPage1)
        Me.tab_control.Controls.Add(Me.TabPage2)
        Me.tab_control.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tab_control.ItemSize = New System.Drawing.Size(180, 40)
        Me.tab_control.Location = New System.Drawing.Point(0, 90)
        Me.tab_control.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.tab_control.Name = "tab_control"
        Me.tab_control.SelectedIndex = 0
        Me.tab_control.Size = New System.Drawing.Size(1095, 507)
        Me.tab_control.TabButtonHoverState.BorderColor = System.Drawing.Color.Empty
        Me.tab_control.TabButtonHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(166, Byte), Integer))
        Me.tab_control.TabButtonHoverState.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!)
        Me.tab_control.TabButtonHoverState.ForeColor = System.Drawing.Color.White
        Me.tab_control.TabButtonHoverState.InnerColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(166, Byte), Integer))
        Me.tab_control.TabButtonIdleState.BorderColor = System.Drawing.Color.Empty
        Me.tab_control.TabButtonIdleState.FillColor = System.Drawing.Color.Transparent
        Me.tab_control.TabButtonIdleState.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!)
        Me.tab_control.TabButtonIdleState.ForeColor = System.Drawing.Color.DimGray
        Me.tab_control.TabButtonIdleState.InnerColor = System.Drawing.Color.Transparent
        Me.tab_control.TabButtonSelectedState.BorderColor = System.Drawing.Color.Empty
        Me.tab_control.TabButtonSelectedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(132, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.tab_control.TabButtonSelectedState.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!)
        Me.tab_control.TabButtonSelectedState.ForeColor = System.Drawing.Color.White
        Me.tab_control.TabButtonSelectedState.InnerColor = System.Drawing.Color.FromArgb(CType(CType(209, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(202, Byte), Integer))
        Me.tab_control.TabButtonSize = New System.Drawing.Size(180, 40)
        Me.tab_control.TabIndex = 19
        Me.tab_control.TabMenuBackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(250, Byte), Integer))
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.lbl_id)
        Me.TabPage1.Controls.Add(Me.btn_deletar)
        Me.TabPage1.Controls.Add(Me.btn_editar)
        Me.TabPage1.Controls.Add(Me.Guna2HtmlLabel5)
        Me.TabPage1.Controls.Add(Me.txt_cliente)
        Me.TabPage1.Controls.Add(Me.btn_criar)
        Me.TabPage1.Controls.Add(Me.Guna2HtmlLabel4)
        Me.TabPage1.Controls.Add(Me.txt_qtde)
        Me.TabPage1.Controls.Add(Me.Guna2HtmlLabel3)
        Me.TabPage1.Controls.Add(Me.cmb_cor)
        Me.TabPage1.Controls.Add(Me.Guna2HtmlLabel6)
        Me.TabPage1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.TabPage1.Controls.Add(Me.cmb_tipo)
        Me.TabPage1.Controls.Add(Me.Guna2HtmlLabel7)
        Me.TabPage1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.TabPage1.Controls.Add(Me.txt_preco)
        Me.TabPage1.Controls.Add(Me.cmb_tamanho)
        Me.TabPage1.Controls.Add(Me.cmb_renda)
        Me.TabPage1.Controls.Add(Me.Guna2PictureBox2)
        Me.TabPage1.Location = New System.Drawing.Point(184, 4)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage1.Size = New System.Drawing.Size(907, 499)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Gerenciar Produtos"
        '
        'lbl_id
        '
        Me.lbl_id.AutoSize = True
        Me.lbl_id.ForeColor = System.Drawing.Color.FromArgb(CType(CType(132, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.lbl_id.Location = New System.Drawing.Point(23, 260)
        Me.lbl_id.Name = "lbl_id"
        Me.lbl_id.Size = New System.Drawing.Size(199, 20)
        Me.lbl_id.TabIndex = 58
        Me.lbl_id.Text = "ID(consulte para completar)"
        '
        'btn_deletar
        '
        Me.btn_deletar.Animated = True
        Me.btn_deletar.AutoRoundedCorners = True
        Me.btn_deletar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(139, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.btn_deletar.BorderRadius = 33
        Me.btn_deletar.BorderThickness = 1
        Me.btn_deletar.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btn_deletar.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btn_deletar.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btn_deletar.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btn_deletar.FillColor = System.Drawing.Color.Transparent
        Me.btn_deletar.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn_deletar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(139, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.btn_deletar.Location = New System.Drawing.Point(540, 298)
        Me.btn_deletar.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_deletar.Name = "btn_deletar"
        Me.btn_deletar.Size = New System.Drawing.Size(152, 68)
        Me.btn_deletar.TabIndex = 57
        Me.btn_deletar.Text = "Deletar"
        '
        'btn_editar
        '
        Me.btn_editar.Animated = True
        Me.btn_editar.AutoRoundedCorners = True
        Me.btn_editar.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.btn_editar.BorderColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.btn_editar.BorderRadius = 33
        Me.btn_editar.BorderThickness = 1
        Me.btn_editar.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btn_editar.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btn_editar.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btn_editar.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btn_editar.FillColor = System.Drawing.Color.White
        Me.btn_editar.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn_editar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.btn_editar.Location = New System.Drawing.Point(192, 298)
        Me.btn_editar.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_editar.Name = "btn_editar"
        Me.btn_editar.Size = New System.Drawing.Size(152, 68)
        Me.btn_editar.TabIndex = 50
        Me.btn_editar.Text = "Editar"
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.Image = Global.definaLingerie.My.Resources.Resources.background_form
        Me.Guna2PictureBox2.ImageRotate = 0!
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(77, 27)
        Me.Guna2PictureBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(580, 386)
        Me.Guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Guna2PictureBox2.TabIndex = 22
        Me.Guna2PictureBox2.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.dgv_dados)
        Me.TabPage2.Location = New System.Drawing.Point(184, 4)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage2.Size = New System.Drawing.Size(907, 499)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Listagem Geral"
        '
        'dgv_dados
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.dgv_dados.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv_dados.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(250, Byte), Integer))
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(132, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(149, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_dados.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgv_dados.ColumnHeadersHeight = 36
        Me.dgv_dados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.dgv_dados.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Nº, Me.Identificador, Me.Nome, Me.Tipo, Me.Quantidade, Me.Preco, Me.Data, Me.Consultar})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(144, Byte), Integer), CType(CType(206, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv_dados.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgv_dados.GridColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgv_dados.Location = New System.Drawing.Point(0, 0)
        Me.dgv_dados.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgv_dados.Name = "dgv_dados"
        Me.dgv_dados.RowHeadersVisible = False
        Me.dgv_dados.RowHeadersWidth = 51
        Me.dgv_dados.RowTemplate.Height = 24
        Me.dgv_dados.Size = New System.Drawing.Size(849, 497)
        Me.dgv_dados.TabIndex = 0
        Me.dgv_dados.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Amethyst
        Me.dgv_dados.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.dgv_dados.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.dgv_dados.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.dgv_dados.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.dgv_dados.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.dgv_dados.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.dgv_dados.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(222, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.dgv_dados.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(132, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.dgv_dados.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgv_dados.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgv_dados.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgv_dados.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.dgv_dados.ThemeStyle.HeaderStyle.Height = 36
        Me.dgv_dados.ThemeStyle.ReadOnly = False
        Me.dgv_dados.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.dgv_dados.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgv_dados.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgv_dados.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgv_dados.ThemeStyle.RowsStyle.Height = 24
        Me.dgv_dados.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(144, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.dgv_dados.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'Nº
        '
        Me.Nº.HeaderText = "Nº"
        Me.Nº.MinimumWidth = 6
        Me.Nº.Name = "Nº"
        '
        'Identificador
        '
        Me.Identificador.HeaderText = "Identificador"
        Me.Identificador.MinimumWidth = 6
        Me.Identificador.Name = "Identificador"
        '
        'Nome
        '
        Me.Nome.HeaderText = "Nome do Cliente"
        Me.Nome.MinimumWidth = 6
        Me.Nome.Name = "Nome"
        '
        'Tipo
        '
        Me.Tipo.HeaderText = "Tipo"
        Me.Tipo.MinimumWidth = 6
        Me.Tipo.Name = "Tipo"
        '
        'Quantidade
        '
        Me.Quantidade.HeaderText = "Quantidade"
        Me.Quantidade.MinimumWidth = 6
        Me.Quantidade.Name = "Quantidade"
        '
        'Preco
        '
        Me.Preco.HeaderText = "Preço"
        Me.Preco.MinimumWidth = 6
        Me.Preco.Name = "Preco"
        '
        'Data
        '
        Me.Data.HeaderText = "Data De Criação"
        Me.Data.MinimumWidth = 6
        Me.Data.Name = "Data"
        '
        'Consultar
        '
        Me.Consultar.HeaderText = "Consultar"
        Me.Consultar.MinimumWidth = 6
        Me.Consultar.Name = "Consultar"
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.BorderRadius = 20
        Me.Guna2Elipse1.TargetControl = Me
        '
        'Guna2ShadowForm1
        '
        Me.Guna2ShadowForm1.TargetForm = Me
        '
        'Guna2DragControl1
        '
        Me.Guna2DragControl1.DockIndicatorTransparencyValue = 0.6R
        Me.Guna2DragControl1.TargetControl = Me.Guna2Panel1
        Me.Guna2DragControl1.UseTransparentDrag = True
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2Panel1.Controls.Add(Me.Guna2ControlBox1)
        Me.Guna2Panel1.Controls.Add(Me.Guna2ControlBox2)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.Size = New System.Drawing.Size(1095, 43)
        Me.Guna2Panel1.TabIndex = 34
        '
        'Guna2ControlBox1
        '
        Me.Guna2ControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox1.FillColor = System.Drawing.Color.Transparent
        Me.Guna2ControlBox1.IconColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Guna2ControlBox1.Location = New System.Drawing.Point(1048, 0)
        Me.Guna2ControlBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2ControlBox1.Name = "Guna2ControlBox1"
        Me.Guna2ControlBox1.Size = New System.Drawing.Size(47, 43)
        Me.Guna2ControlBox1.TabIndex = 0
        '
        'Guna2ControlBox2
        '
        Me.Guna2ControlBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox
        Me.Guna2ControlBox2.FillColor = System.Drawing.Color.Transparent
        Me.Guna2ControlBox2.IconColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.Guna2ControlBox2.Location = New System.Drawing.Point(1000, 0)
        Me.Guna2ControlBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2ControlBox2.Name = "Guna2ControlBox2"
        Me.Guna2ControlBox2.Size = New System.Drawing.Size(47, 43)
        Me.Guna2ControlBox2.TabIndex = 1
        '
        'Guna2AnimateWindow1
        '
        Me.Guna2AnimateWindow1.AnimationType = Guna.UI2.WinForms.Guna2AnimateWindow.AnimateWindowType.AW_BLEND
        Me.Guna2AnimateWindow1.TargetForm = Me
        '
        'ts_filtro
        '
        Me.ts_filtro.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.ts_filtro.BackColor = System.Drawing.Color.Transparent
        Me.ts_filtro.Dock = System.Windows.Forms.DockStyle.None
        Me.ts_filtro.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ts_filtro.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1, Me.txt_valor, Me.ToolStripLabel2, Me.cmb_parametro, Me.btn_filtrar})
        Me.ts_filtro.Location = New System.Drawing.Point(245, 50)
        Me.ts_filtro.Name = "ts_filtro"
        Me.ts_filtro.Size = New System.Drawing.Size(598, 28)
        Me.ts_filtro.TabIndex = 57
        Me.ts_filtro.Text = "ToolStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.ForeColor = System.Drawing.Color.DimGray
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(201, 25)
        Me.ToolStripLabel1.Text = "Insira o valor correspodente"
        '
        'txt_valor
        '
        Me.txt_valor.BackColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.txt_valor.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_valor.ForeColor = System.Drawing.Color.DimGray
        Me.txt_valor.Name = "txt_valor"
        Me.txt_valor.Size = New System.Drawing.Size(100, 28)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel2.ForeColor = System.Drawing.Color.DimGray
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(176, 25)
        Me.ToolStripLabel2.Text = "Selecione um parâmetro"
        '
        'cmb_parametro
        '
        Me.cmb_parametro.BackColor = System.Drawing.Color.FromArgb(CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.cmb_parametro.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_parametro.ForeColor = System.Drawing.Color.DimGray
        Me.cmb_parametro.Name = "cmb_parametro"
        Me.cmb_parametro.Size = New System.Drawing.Size(75, 28)
        '
        'btn_filtrar
        '
        Me.btn_filtrar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_filtrar.Image = CType(resources.GetObject("btn_filtrar.Image"), System.Drawing.Image)
        Me.btn_filtrar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_filtrar.Name = "btn_filtrar"
        Me.btn_filtrar.Size = New System.Drawing.Size(29, 25)
        Me.btn_filtrar.Text = "ToolStripButton1"
        '
        'btn_deslogar
        '
        Me.btn_deslogar.BackColor = System.Drawing.Color.Transparent
        Me.btn_deslogar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_deslogar.Image = Global.definaLingerie.My.Resources.Resources.icons8_quit_50
        Me.btn_deslogar.ImageRotate = 0!
        Me.btn_deslogar.Location = New System.Drawing.Point(1032, 41)
        Me.btn_deslogar.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_deslogar.Name = "btn_deslogar"
        Me.btn_deslogar.Size = New System.Drawing.Size(57, 53)
        Me.btn_deslogar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btn_deslogar.TabIndex = 55
        Me.btn_deslogar.TabStop = False
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.BorderRadius = 28
        Me.Guna2PictureBox1.Image = Global.definaLingerie.My.Resources.Resources.definaLogo
        Me.Guna2PictureBox1.ImageRotate = 0!
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(16, 15)
        Me.Guna2PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(75, 69)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox1.TabIndex = 31
        Me.Guna2PictureBox1.TabStop = False
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1095, 593)
        Me.Controls.Add(Me.ts_filtro)
        Me.Controls.Add(Me.btn_deslogar)
        Me.Controls.Add(Me.Guna2PictureBox1)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Controls.Add(Me.tab_control)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form6"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form6"
        Me.tab_control.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.dgv_dados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2Panel1.ResumeLayout(False)
        Me.ts_filtro.ResumeLayout(False)
        Me.ts_filtro.PerformLayout()
        CType(Me.btn_deslogar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmb_renda As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents cmb_cor As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents cmb_tamanho As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents cmb_tipo As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents btn_criar As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents txt_cliente As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt_preco As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txt_qtde As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents tab_control As Guna.UI2.WinForms.Guna2TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Guna2ShadowForm1 As Guna.UI2.WinForms.Guna2ShadowForm
    Friend WithEvents Guna2DragControl1 As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents Guna2AnimateWindow1 As Guna.UI2.WinForms.Guna2AnimateWindow
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2ControlBox1 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2ControlBox2 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents btn_deslogar As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents btn_editar As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btn_deletar As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents dgv_dados As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents ts_filtro As ToolStrip
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents txt_valor As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_parametro As ToolStripComboBox
    Friend WithEvents btn_filtrar As ToolStripButton
    Friend WithEvents Nº As DataGridViewTextBoxColumn
    Friend WithEvents Identificador As DataGridViewTextBoxColumn
    Friend WithEvents Nome As DataGridViewTextBoxColumn
    Friend WithEvents Tipo As DataGridViewTextBoxColumn
    Friend WithEvents Quantidade As DataGridViewTextBoxColumn
    Friend WithEvents Preco As DataGridViewTextBoxColumn
    Friend WithEvents Data As DataGridViewTextBoxColumn
    Friend WithEvents Consultar As DataGridViewImageColumn
    Friend WithEvents lbl_id As Label
End Class
