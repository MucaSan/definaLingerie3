﻿Imports System.Data.SQLite
Imports System.Security.Cryptography

Public Class Form4
    Private dbCommand As String = ""
    Private bindingSrc As BindingSource

    Private dbName As String = "banco.db"
    Private dbPath As String = Application.StartupPath & "\banco\" & dbName
    Private conString As String = "Data Source=" & dbPath & ";Version=3"

    Private connection As New SQLiteConnection(conString)

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection.Open()
        cmb_parametro.Items.Add("CPF")
        cmb_parametro.Items.Add("Usuário")


    End Sub
    Sub limpar_campos()
        txt_cpf.Text = ""
        txt_email.Text = ""
        txt_nome.Text = ""
        txt_senha.Text = ""
        txt_telefone.Text = ""
        txt_user.Text = ""
        txt_valor.Text = ""
    End Sub

    Private Sub btn_filtrar_Click(sender As Object, e As EventArgs) Handles btn_filtrar.Click
        Dim sql As String
        If cmb_parametro.SelectedItem = "Usuário" Then
            sql = "select * from tb_funcionarios where usuario like '" & txt_valor.Text & "%' and cargo=2;"
            Dim command As New SQLiteCommand(sql, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                Try
                    cont = 1
                    dgv_dados.Rows.Clear()
                    While reader.Read()
                        dgv_dados.Rows.Add(cont, reader("cpf"), reader("nome"), reader("usuario"), reader("senha"))
                        cont = cont + 1
                    End While
                    tab_control.SelectedIndex = 1
                Catch ex As Exception
                    MsgBox("Não há um registro com esse Usuário! Ou foi inserido um parametro errado", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
                End Try
            End Using
        ElseIf cmb_parametro.SelectedItem = "CPF" Then
            sql = "select * from tb_funcionarios where cpf like '" & txt_valor.Text & "%' AND cargo = 2;"
            Dim command As New SQLiteCommand(sql, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                Try
                    cont = 1
                    dgv_dados.Rows.Clear()
                    While reader.Read()
                        dgv_dados.Rows.Add(cont, reader("cpf"), reader("nome"), reader("usuario"), reader("senha"))
                        cont = cont + 1
                    End While
                    tab_control.SelectedIndex = 1
                Catch ex As Exception
                    MsgBox("Não há um registro com esse CPF! Ou foi inserido um parametro errado", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
                End Try
            End Using
        Else
            MsgBox("Escolha um parâmetro, antes de filtrar!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
        End If
    End Sub

    Private Sub btn_deletar_Click(sender As Object, e As EventArgs) Handles btn_deletar.Click
        Dim sql As String = "SELECT * FROM tb_funcionarios WHERE usuario='" & txt_user.Text & "';"
        Dim command As New SQLiteCommand(sql, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                sql = "DELETE FROM tb_funcionarios WHERE usuario= '" & txt_user.Text & "'"
                Dim command2 As New SQLiteCommand(sql, connection)
                Try
                    resp = MsgBox("Quer mesmo realizar a deleção?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
                    If resp = vbYes Then
                        command2.ExecuteNonQuery()
                        MsgBox("Deleção efetuada com sucesso!")
                        limpar_campos()
                    Else
                        Exit Sub

                    End If
                Catch ex As Exception
                    MsgBox("Não foi possível realizar a deleção!")
                End Try
            End If
        End Using
    End Sub

    Private Sub btn_criar_Click(sender As Object, e As EventArgs) Handles btn_criar.Click
        Dim sql As String = "SELECT * FROM tb_funcionarios WHERE usuario='" & txt_user.Text & "';"
        Dim command As New SQLiteCommand(sql, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                If reader("usuario") = txt_user.Text Or reader("nome") = txt_nome.Text Then
                    MsgBox("Há um registro com esse usuário ou nome, insira outro nome ou usuário!", MsgBoxStyle.OkOnly + MsgBoxStyle.Critical)
                    txt_user.Clear()
                    txt_nome.Clear()
                End If
            Else
                Try
                    sql = "INSERT INTO tb_funcionarios VALUES ('" & txt_cpf.Text & "','" & txt_nome.Text & "','" & txt_user.Text & "','" & txt_senha.Text & "','" & cmb_data.Text & "','" & txt_email.Text & "','" & txt_telefone.Text & "',2);"
                    Dim command2 As New SQLiteCommand(sql, connection)
                    command2.ExecuteNonQuery()
                    MsgBox("CRIAÇÃO EFETUADA COM SUCESSO!")
                    limpar_campos()
                Catch ex As Exception
                    MsgBox("Não foi possível realizar a criação!")
                End Try
            End If
        End Using
    End Sub

    Private Sub Form4_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        connection.Close()
    End Sub

    Private Sub btn_deslogar_Click(sender As Object, e As EventArgs) Handles btn_deslogar.Click
        Me.Close()
        Form2.Show()
    End Sub

    Private Sub TabPage1_ContextMenuChanged(sender As Object, e As EventArgs) Handles TabPage1.ContextMenuChanged
        ts_filtro.Show()

    End Sub

    Private Sub TabPage2_ContextMenuChanged(sender As Object, e As EventArgs) Handles TabPage2.ContextMenuChanged
        ts_filtro.hide()
    End Sub

    Private Sub ts_filtro_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles ts_filtro.ItemClicked

    End Sub

    Private Sub btn_editar_Click(sender As Object, e As EventArgs) Handles btn_editar.Click
        Dim sql As String = "SELECT * FROM tb_funcionarios WHERE usuario='" & txt_user.Text & "';"
        Dim command As New SQLiteCommand(sql, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                Dim update_cpf As String = reader("cpf").ToString()
                Dim update_nome As String = reader("nome").ToString()
                Dim update_senha As String = reader("senha").ToString()
                Dim update_user As String = reader("usuario").ToString()
                Dim update_data As String = reader("data_nascimento").ToString()
                Dim update_email As String = reader("email").ToString()
                Dim update_telefone As String = reader("telefone").ToString()
                sql = "UPDATE tb_funcionarios SET cpf = '" & txt_cpf.Text & "', nome= '" & txt_nome.Text & "', usuario='" & txt_user.Text & "', senha='" & txt_senha.Text & "', data_nascimento='" & cmb_data.Text & "', email='" & txt_email.Text & "',telefone='" & txt_telefone.Text & "', cargo= 2 where usuario='" & update_user & "'"
                Dim command2 As New SQLiteCommand(sql, connection)
                Try
                    command2.ExecuteNonQuery()
                    MsgBox("EDIÇÃO FEITA COM SUCESSO!")
                    limpar_campos()
                Catch ex As Exception
                    MsgBox("Foi impossível realizar a edição do usuário!")
                End Try
            Else
                MsgBox("Não há cadastro existente com esse nome de usuário!", MsgBoxStyle.Exclamation + vbOKOnly)
            End If
        End Using
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Dim sql As String
        With dgv_dados
            If .CurrentRow.Cells(5).Selected Then
                Dim aux_cpf As String = .CurrentRow.Cells(1).Value
                sql = "SELECT * FROM tb_funcionarios WHERE cpf='" & aux_cpf & "';"
                Dim command As New SQLiteCommand(sql, connection)
                Using reader As SQLiteDataReader = command.ExecuteReader()
                    Try
                        If reader.Read() Then
                            tab_control.SelectedIndex = 0
                            txt_cpf.Text = reader("cpf").ToString()
                            cmb_data.Text = reader("data_nascimento").ToString()
                            txt_nome.Text = reader("nome").ToString()
                            txt_email.Text = reader("email").ToString()
                            txt_telefone.Text = reader("telefone").ToString()
                            txt_user.Text = reader("usuario").ToString()
                            txt_senha.Text = reader("senha").ToString()
                        End If
                    Catch ex As Exception
                        MsgBox("Não foi possível passar as informações para o campo!")
                    End Try
                End Using
            End If
        End With
    End Sub

    Private Sub txt_nome_Load(sender As Object, e As EventArgs) Handles txt_nome.Load

    End Sub
End Class