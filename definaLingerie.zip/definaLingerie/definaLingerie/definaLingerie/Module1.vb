﻿Module Module1
    Public funcionario_logado As String
    Public cont As Integer
    Public resp As String
    Public soma As Integer


End Module
