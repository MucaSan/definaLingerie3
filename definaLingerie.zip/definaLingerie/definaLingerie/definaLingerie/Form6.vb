﻿Imports System.Data.Common
Imports System.Data.SQLite
Imports System.Web.UI.WebControls
Imports System.Windows.Forms.Design

Public Class Form6
    Private dbCommand As String = ""
    Private permitir_criar As Boolean = True
    Private bindingSrc As BindingSource
    Private cont As Integer = 0
    Private dbName As String = "banco.db"
    Private dbPath As String = Application.StartupPath & "\banco\" & dbName
    Private conString As String = "Data Source=" & dbPath & ";Version=3"
    Private SQL As String
    Private connection As New SQLiteConnection(conString)

    Sub limpar_campos()
        txt_cliente.Text = ""
        txt_preco.Text = ""
        txt_qtde.Text = ""
        cmb_cor.Text = ""
        cmb_renda.Text = ""
        cmb_tamanho.Text = ""
        cmb_tipo.Text = ""
    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection.Open()
        SQL = "SELECT cor from tb_cor;"
        Dim command As New SQLiteCommand(SQL, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            While reader.Read()
                cmb_cor.Items.Add(reader("cor"))
            End While
        End Using
        SQL = "SELECT tipo from tb_tipo;"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            While reader.Read()
                cmb_tipo.Items.Add(reader("tipo"))
            End While
        End Using
        SQL = "SELECT tamanho from tb_tamanho;"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            While reader.Read()
                cmb_tamanho.Items.Add(reader("tamanho"))
            End While
        End Using
        SQL = "SELECT cond_renda from tb_renda;"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            While reader.Read()
                cmb_renda.Items.Add(reader("cond_renda"))
            End While
        End Using
        cmb_parametro.Items.Add("Identificador")
        cmb_parametro.Items.Add("Nome do Cliente")
    End Sub

    Private Sub cmb_renda_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_renda.SelectedIndexChanged
        Dim command As New SQLiteCommand(SQL, connection)
        Dim verif_tipo As Integer
        Dim verif_tamanho As Integer
        Dim verif_renda As Integer
        SQL = "SELECT id from tb_tipo where tipo = '" & cmb_tipo.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_tipo = CInt(reader("id"))
            End If
        End Using
        SQL = "SELECT id from tb_tamanho where tamanho = '" & cmb_tamanho.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_tamanho = CInt(reader("id"))
            End If
        End Using
        SQL = "SELECT id from tb_renda where cond_renda = '" & cmb_renda.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_renda = CInt(reader("id"))
            End If
        End Using

        SQL = "SELECT preco from tb_preco WHERE tamanho = '" & verif_tamanho & "' AND tipo = '" & verif_tipo & "' AND renda = '" & verif_renda & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                txt_preco.Text = reader("preco")
                cont = 0
                If txt_qtde.Text = Nothing Then
                    Exit Sub
                Else
                    txt_qtde_TextChanged(sender, e)
                End If

            End If
        End Using
    End Sub

    Private Sub cmb_tipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_tipo.SelectedIndexChanged
        Dim command As New SQLiteCommand(SQL, connection)
        Dim verif_tipo As Integer
        Dim verif_tamanho As Integer
        Dim verif_renda As Integer
        SQL = "SELECT id from tb_tipo where tipo = '" & cmb_tipo.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_tipo = CInt(reader("id"))
            End If
        End Using
        SQL = "SELECT id from tb_tamanho where tamanho = '" & cmb_tamanho.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_tamanho = CInt(reader("id"))
            End If
        End Using
        SQL = "SELECT id from tb_renda where cond_renda = '" & cmb_renda.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_renda = CInt(reader("id"))
            End If
        End Using
        SQL = "SELECT preco from tb_preco WHERE tamanho = '" & verif_tamanho & "' AND tipo = '" & verif_tipo & "' AND renda = '" & verif_renda & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                txt_preco.Text = reader("preco")
                cont = 0
                If txt_qtde.Text = Nothing Then
                    Exit Sub
                Else
                    txt_qtde_TextChanged(sender, e)
                End If

            End If
        End Using
    End Sub

    Private Sub cmb_tamanho_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_tamanho.SelectedIndexChanged
        Dim command As New SQLiteCommand(SQL, connection)
        Dim verif_tipo As Integer
        Dim verif_tamanho As Integer
        Dim verif_renda As Integer
        SQL = "SELECT id from tb_tipo where tipo = '" & cmb_tipo.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_tipo = CInt(reader("id"))
            End If
        End Using
        SQL = "SELECT id from tb_tamanho where tamanho = '" & cmb_tamanho.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_tamanho = CInt(reader("id"))
            End If
        End Using
        SQL = "SELECT id from tb_renda where cond_renda = '" & cmb_renda.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                verif_renda = CInt(reader("id"))
            End If
        End Using

        SQL = "SELECT preco from tb_preco WHERE tamanho = '" & verif_tamanho & "' AND tipo = '" & verif_tipo & "' AND renda = '" & verif_renda & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                txt_preco.Text = reader("preco")
                cont = 0
                If txt_qtde.Text = Nothing Then
                    Exit Sub
                Else
                    txt_qtde_TextChanged(sender, e)
                End If
            End If
        End Using
    End Sub

    Private Sub txt_qtde_TextChanged(sender As Object, e As EventArgs) Handles txt_qtde.TextChanged
        Try
            Dim integer_preco As Integer
            Dim integer_qtde As Integer
            Dim integer_result As Integer
            If txt_preco.Text = Nothing Then
                permitir_criar = False
                Exit Sub
            ElseIf cont < 1 Then
                integer_preco = CInt(txt_preco.Text)
                integer_qtde = CInt(txt_qtde.Text)
                integer_result = integer_preco * integer_qtde
                txt_preco.Text = integer_result.ToString()
                permitir_criar = True
                cont += 1
            End If
        Catch ex As Exception
            MsgBox("Insira um valor válido dentro da quantidade! Não é aceito letras nem caracteres especiais!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
            permitir_criar = False

        End Try
    End Sub
    Private Sub btn_criar_Click(sender As Object, e As EventArgs) Handles btn_criar.Click
        SQL = "SELECT * from tb_produtos;"
        Dim command As New SQLiteCommand(SQL, connection)
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            cont = 1
            While reader.Read()
                cont = cont + 1
            End While
        End Using
        SQL = "SELECT nome from tb_clientes where nome = '" & txt_cliente.Text & "';"
        command.CommandText = SQL
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                permitir_criar = True
            Else
                MsgBox("Você inseriu o nome do cliente errado, ou ele não existe!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
                permitir_criar = False
            End If
        End Using
        SQL = "INSERT INTO tb_produtos VALUES ('" & cont & "','" & funcionario_logado & "','" & cmb_tamanho.Text & "','" & txt_cliente.Text & "','" & cmb_renda.Text & "','" & txt_preco.Text & "','" & cmb_cor.Text & "','" & txt_qtde.Text & "','" & cmb_tipo.Text & "','" & DateTime.Now.ToString() & "');"
        command.CommandText = SQL
        Select Case permitir_criar
            Case True
                Try
                    command.ExecuteNonQuery()
                    MsgBox("Criação efetuada com sucesso!")
                    limpar_campos()

                Catch ex As Exception
                    MsgBox("Foi impossível realizar a criação do produto, porque provavelmente foram inseridos valores inválidos nos campos!")
                End Try
            Case Else
                MsgBox("Você completou os campos de forma indevida! Tente novamente após as mudanças!")
                Exit Sub

        End Select

    End Sub

    Private Sub btn_deslogar_Click(sender As Object, e As EventArgs) Handles btn_deslogar.Click

        Form3.Show()
        Me.Close()
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Dim sql As String
        With dgv_dados
            If .CurrentRow.Cells(7).Selected Then
                Dim aux_id As String = .CurrentRow.Cells(1).Value
                sql = "SELECT * FROM tb_produtos WHERE id='" & aux_id & "' AND n_func = '" & funcionario_logado & "';"
                Dim command As New SQLiteCommand(sql, connection)
                Using reader As SQLiteDataReader = command.ExecuteReader()
                    Try
                        If reader.Read() Then
                            txt_cliente.Text = reader("n_cliente").ToString()
                            txt_preco.Text = reader("preco").ToString()
                            txt_qtde.Text = reader("qtde").ToString()
                            cmb_cor.Text = reader("cor").ToString()
                            cmb_renda.Text = reader("c_renda").ToString()
                            cmb_tipo.Text = reader("tipo").ToString()
                            cmb_tamanho.Text = reader("tamanho").ToString()
                            lbl_id.Text = reader("id").ToString()
                            tab_control.SelectedIndex = 0
                            dgv_dados.ClearSelection()
                        End If
                    Catch ex As Exception
                        MsgBox("Não foi possível passar as informações para o campo!")
                    End Try
                End Using
            End If
        End With
    End Sub

    Private Sub btn_filtrar_Click(sender As Object, e As EventArgs) Handles btn_filtrar.Click
        Dim sql As String
        If cmb_parametro.SelectedItem = "Identificador" Then
            sql = "select * from tb_produtos where id='" & txt_valor.Text & "' AND n_func = '" & funcionario_logado & "' " ' adicionar um filtro por quem criou a conta.
            Dim command As New SQLiteCommand(sql, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                Try
                    cont = 1
                    dgv_dados.Rows.Clear()
                    While reader.Read()
                        dgv_dados.Rows.Add(cont.ToString(), reader("id").ToString(), reader("n_cliente").ToString(), reader("tipo").ToString(), reader("qtde").ToString(), reader("preco").ToString(), reader("data_criacao").ToString())
                        cont = cont + 1
                    End While
                    Select Case cont
                        Case 1
                            MsgBox("Você está tentando acessar um cliente em que não tem acesso! Ou não completou os parâmetros do filtro!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
                        Case Else
                            tab_control.SelectedIndex = 1
                    End Select
                Catch ex As Exception
                    MsgBox("Não há um registro com esse Identificador! Ou foi inserido um parametro errado", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
                End Try
            End Using
        ElseIf cmb_parametro.SelectedItem = "Nome do Cliente" Then
            sql = "select * from tb_produtos where n_cliente like '" & txt_valor.Text & "%' AND n_func = '" & funcionario_logado & "'"
            Dim command As New SQLiteCommand(sql, connection)
            Using reader As SQLiteDataReader = command.ExecuteReader()
                Try
                    cont = 1
                    dgv_dados.Rows.Clear()
                    While reader.Read()
                        dgv_dados.Rows.Add(cont.ToString(), reader("id").ToString(), reader("n_cliente").ToString(), reader("tipo").ToString(), reader("qtde").ToString(), reader("preco").ToString(), reader("data_criacao").ToString())
                        cont = cont + 1
                    End While
                    Select Case cont
                        Case 1
                            MsgBox("Você está tentando acessar um cliente em que não tem acesso!")
                        Case Else
                            tab_control.SelectedIndex = 1
                    End Select
                Catch ex As Exception
                    MsgBox("Não há um registro com esse Nome de Cliente! Ou foi inserido um parametro errado", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
                End Try
            End Using
        Else
            MsgBox("Escolha um parâmetro, antes de filtrar!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO!")
        End If
    End Sub

    Private Sub btn_editar_Click(sender As Object, e As EventArgs) Handles btn_editar.Click
        Dim SQL As String
        SQL = "SELECT n_cliente from tb_produtos where id = '" & lbl_id.Text & "' AND n_func = '" & funcionario_logado & "';"
        Dim command As New SQLiteCommand(SQL, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                SQL = "SELECT nome from tb_clientes where nome = '" & txt_cliente.Text & "' AND n_func = '" & funcionario_logado & "';"
                Dim command2 As New SQLiteCommand(SQL, connection)
                Using reader2 As SQLiteDataReader = command2.ExecuteReader()
                    MsgBox(command2.CommandText)
                    If reader2.Read() Then
                        SQL = "UPDATE tb_produtos SET tamanho='" & cmb_tamanho.Text & "',n_cliente='" & txt_cliente.Text & "',c_renda='" & cmb_renda.Text & "',preco='" & txt_preco.Text & "',cor='" & cmb_cor.Text & "',qtde='" & txt_qtde.Text & "',tipo='" & cmb_tipo.Text & "' where id='" & lbl_id.Text() & "' AND n_func = '" & funcionario_logado & "';"
                        Dim command3 As New SQLiteCommand(SQL, connection)
                        command3.ExecuteNonQuery()
                        MsgBox("Edição feita com sucesso!")
                        limpar_campos()
                    Else
                        MsgBox("Você alterou o nome do cliente para um que não existe, por favor consulte novamente!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
                    End If
                End Using
            Else
                MsgBox("Você deve consultar os dados do cliente pelo filtro!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
            End If
        End Using
    End Sub

    Private Sub btn_deletar_Click(sender As Object, e As EventArgs) Handles btn_deletar.Click
        Dim SQL As String
        SQL = "SELECT n_cliente from tb_produtos where id = '" & lbl_id.Text & "' AND n_func = '" & funcionario_logado & "';"
        Dim command As New SQLiteCommand(SQL, connection)
        Using reader As SQLiteDataReader = command.ExecuteReader()
            If reader.Read() Then
                SQL = "SELECT nome from tb_clientes where nome = '" & txt_cliente.Text & "' AND n_func = '" & funcionario_logado & "';"
                Dim command2 As New SQLiteCommand(SQL, connection)
                Using reader2 As SQLiteDataReader = command2.ExecuteReader()
                    MsgBox(command2.CommandText)
                    If reader2.Read() Then
                        resp = MsgBox("Você deseja realizar a deleção?", MsgBoxStyle.Question + MsgBoxStyle.YesNo)
                        If resp = vbYes Then
                            SQL = "DELETE from tb_produtos where id= '" & lbl_id.Text & "'"
                            Dim command3 As New SQLiteCommand(SQL, connection)
                            command3.ExecuteNonQuery()
                            MsgBox("Deleção feita com sucesso!")
                        Else
                            Exit Sub
                        End If

                    Else
                        MsgBox("Você alterou o nome do cliente para um que não existe, por favor consulte novamente!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
                    End If
                End Using
            Else
                MsgBox("Você deve consultar os dados do cliente pelo filtro!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
            End If
        End Using
    End Sub
End Class